package Tpjava;

public class main {
    public static void main(String[] args) {

        System.out.println("=== PARTE 1 - Demo del reproductor ===");

        ReproductorMusical reproductor = new ReproductorSpotify();

        cancion c1 = new cancion("1", "Luz de Neón", "Los Cronómetros", "Rock", 210, 154000L, false);

        reproductor.reproducir(c1);
        reproductor.pausar();
        reproductor.detener();

        System.out.println();

        PartesMias.main(args);
    }
}
