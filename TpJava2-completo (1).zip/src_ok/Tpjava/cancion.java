package Tpjava;

public class cancion {
    private String id;
    private String titulo;
    private String artista;
    private String genero;
    private int duracionSegundos;
    private long reproducciones;
    private boolean esPremium;

    public cancion(String id, String titulo, String artista, String genero, int duracionSegundos, long reproducciones, boolean esPremium) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
        this.duracionSegundos = duracionSegundos;
        this.reproducciones = reproducciones;
        this.esPremium = esPremium;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getArtista() { return artista; }
    public void setArtista(String artista) { this.artista = artista; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public int getDuracionSegundos() { return duracionSegundos; }
    public void setDuracionSegundos(int duracionSegundos) { this.duracionSegundos = duracionSegundos; }

    public long getReproducciones() { return reproducciones; }
    public void setReproducciones(long reproducciones) { this.reproducciones = reproducciones; }

    public boolean isEsPremium() { return esPremium; }
    public void setEsPremium(boolean esPremium) { this.esPremium = esPremium; }
}
